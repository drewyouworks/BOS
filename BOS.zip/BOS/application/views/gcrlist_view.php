<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-header">
                    <h3>GC Requests</h3>
                </div>
            </div>
        </div>
        <div class="container-fluid"
        <div class="row">
            <div class="col-lg-12">
                <div>
                    <a class="btn btn-default" href = "<?php echo base_url('gcrequest/add')?>">
                        <span class = "glyphicon glyphicon-plus"></span>
                        <span>Add New Request</span>
                    </a>
                </div>
                <br/>
                <?php if(count($list) > 0){?>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" style="white-space: nowrap; font-size: 12px">
                        <thead>
                            <tr style ="text-align: center">
                                <td rowspan="2" style ="vertical-align:middle;"><b>Store Code</b></td>
                                <td colspan="2"><b>JPLS Target Dates</b></td>
                                <td colspan="2"><b>Totals</b></td>
                                <td colspan="6"><b>Addition</b></td>
                                <td rowspan="2"></td>
                            </tr>
                            <tr style ="text-align: center">
                                <td><b>Nov 15 - Dec 13</b></td>
                                <td><b>Dec 14 - Dec 31</b></td>
                                <td><b>JPLS Target</b></td>
                                <td><b>Initial GC Requese</b></td>
                                <td><b>50 GC</b></td>
                                <td><b>Amount</b></td>
                                <td><b>100 GC</b></td>
                                <td><b>Amount</b></td>
                                <td><b>Pie GC</b></td>
                                <td><b>Amount</b></td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($list as $list_item): ?>
                            <tr style ="text-align: center">
                                <td><?php echo $list_item['store_code']?></td>
                                <td><?php echo $list_item['jstarget_nov']?></td>
                                <td><?php echo $list_item['jstarget_dec']?></td>
                                <td><?php echo $list_item['jstarget_total']?></td>
                                <td><?php echo $list_item['ini_gcrequest']?></td>
                                <td><?php echo $list_item['add_50gc']?></td>
                                <td><?php echo $list_item['gc50_amt']?></td>
                                <td><?php echo $list_item['add_100gc']?></td>
                                <td><?php echo $list_item['gc100_amt']?></td>
                                <td><?php echo $list_item['add_piegc']?></td>
                                <td><?php echo $list_item['gcpie_amt']?></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href ="<?php echo base_url('gcrequest/edit?id='.$list_item['id'])?>" type="button" class="btn btn-primary"><span class="glyphicon glyphicon-pencil"></span></a>
                                        <a href ="<?php echo base_url('gcrequest/addrequest?id='.$list_item['id'])?>" type="button" class="btn btn-warning"><span class="glyphicon glyphicon-plus"></span></a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php } else { ?>
                    <div class="alert alert-warning alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        No Records Found.
                    </div>
                <?php } ?>
            </div>
            <!-- /.col-lg-12 -->
        </div>
    </div>
    <!-- /.row -->
</div>
<!-- /.container-fluid -->
</div>