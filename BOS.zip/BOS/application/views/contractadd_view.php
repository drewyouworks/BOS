<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-header">
                    <h3>Contract Entry</h3>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <?php echo form_open(base_url('contract/add'));?>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Contract #</label>
                    <input type="text" class="form-control" id="contractno" name="contractno" placeholder="Contract #"
                           value="<?php echo set_value('contractno'); ?>">
                    <span class="text-danger"><?php echo form_error('contractno'); ?></span>
                </div>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Contract Name</label>
                    <input type="text" class="form-control" id="contractname" name="contractname" placeholder="Contract Name"
                           value="<?php echo set_value('contractname'); ?>">
                    <span class="text-danger"><?php echo form_error('contractname'); ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Contact Person</label>
                    <input type="text" class="form-control" id="contactperson" name="contactperson" placeholder="Contact Person"
                           value="<?php echo set_value('contactperson'); ?>">
                    <span class="text-danger"><?php echo form_error('contactperson'); ?></span>
                </div>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Address</label>
                    <input type="text" class="form-control" id="address" name="address" placeholder="Address"
                           value="<?php echo set_value('address'); ?>">
                    <span class="text-danger"><?php echo form_error('address'); ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Landline #</label>
                    <input type="text" class="form-control" id="landline" name="landline" placeholder="Landlinet #"
                           value="<?php echo set_value('landline'); ?>">
                    <span class="text-danger"><?php echo form_error('landline'); ?></span>
                </div>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Mobile #</label>
                    <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Mobile #"
                           value="<?php echo set_value('mobile'); ?>">
                    <span class="text-danger"><?php echo form_error('mobile'); ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Previous Customer?</label>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <input type="checkbox" id="prevcust" name="prevcust" placeholder="Previous Customer"
                                   <?php if(set_value('prevcust') == 'on') echo 'checked = "on"'; ?>>
                        </span>
                        <input type="text" class="form-control date" id="custsince" name="custsince" placeholder="Since When?"
                               value="<?php echo set_value('custsince'); ?>">
                    </div>
                    <span class="text-danger"><?php echo form_error('custsince'); ?></span>
                </div>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Date Booked</label>
                    <input type="text" class="form-control date" id="datebooked" name="datebooked" placeholder="Date Booked"
                                   value="<?php echo set_value('datebooked'); ?>">
                    <span class="text-danger"><?php echo form_error('datebooked'); ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>BOS Transaction</label>
                    <select type="text" class="form-control" id="bostransac" name="bostransac">
                        <option value >Select BOS Type</option>
                        <option value="Single" <?php if(set_value('bostransac') == 'Single') echo 'selected'; ?>>Single</option>
                        <option value="Multiple" <?php if(set_value('bostransac') == 'Multiple') echo 'selected'; ?>>Multiple</option>
                    </select>
                    <span class="text-danger"><?php echo form_error('bostransac'); ?></span>
                    
                </div>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Type of Order</label>
                    <select type="text" class="form-control" id="ordertype" name="ordertype">
                        <option value >Select Order Type</option>
                        <option value="BOS" <?php if(set_value('ordertype') == 'BOS') echo 'selected'; ?>>BOS</option>
                        <option value="JPLS" <?php if(set_value('ordertype') == 'JPLS') echo 'selected'; ?>>JPLS</option>
                        <option value="NKAG" <?php if(set_value('ordertype') == 'NKAG') echo 'selected'; ?>>NKAG</option>
                    </select>
                    <span class="text-danger"><?php echo form_error('ordertype'); ?></span>
                </div>
                <div class="clearfix"></div><br/>


                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4" >
                    <label >Shared Order : </label>
                    <input type="checkbox"  id="shared" name="shared" placeholder="Shared Order?"
                        <?php if(set_value('shared') == 'on') echo 'checked = "on"'; ?>">
                    <span class="text-danger"><?php echo form_error('shared'); ?></span>
                </div>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Mother Store : </label>
                    <input type="checkbox" id="mother" name="mother" placeholder="mother"
                        <?php if(set_value('mother') == 'on') echo 'checked = "on"'; ?>">
                    <span class="text-danger"><?php echo form_error('mother'); ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Customer Profile</label>
                    <select type="text" class="form-control" id="custprofile" name="custprofile" placeholder="Customer Profile">
                        <option value >Select Profile</option>
                        <option value="School Govt" <?php if(set_value('custprofile') == 'School Govt') echo 'selected'; ?>>School Gov't</option>
                        <option value="School Private" <?php if(set_value('custprofile') == 'School Private') echo 'selected'; ?>>School Private</option>
                        <option value="Office Govt" <?php if(set_value('custprofile') == 'Office Govt') echo 'selected'; ?>>Office Gov't</option>
                        <option value="Office Private" <?php if(set_value('custprofile') == 'Office Govt') echo 'selected'; ?>>Office Private</option>
                        <option value="Others" <?php if(set_value('custprofile') == 'Others') echo 'selected'; ?>>Others</option>
                    </select>
                    <span class="text-danger"><?php echo form_error('custprofile'); ?></span>
                </div>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>if Others, Specify</label>
                    <input type="text" class="form-control" id="otherprofile" name="otherprofile" placeholder="Other Profile"
                           value="<?php echo set_value('otherprofile'); ?>">
                    <span class="text-danger"><?php echo form_error('otherprofile'); ?></span>
                </div>
                <div class="clearfix"></div>



                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <button id="btn_login" name="btn_add" type="submit" class="btn btn-primary" value="add">Add Contract</button>
                </div>
                <?php echo form_close(); ?>
                <div class="clearfix"></div>

                <br /><br />
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<script type="text/javascript">

    $('.date').datepicker({
        todayBtn: true,
        forceParse: false,
        autoclose: true,
        todayHighlight: true
    });
</script>

