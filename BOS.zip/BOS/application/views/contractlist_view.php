<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-header">
                    <h3>Contracts</h3>
                </div>
            </div>
        </div>
        <div class="container-fluid"
            <div class="row">
                <div class="col-lg-12">
                    <div>
                        <a class="btn btn-default" href = "<?php echo base_url('contract/add')?>">
                            <span class = "glyphicon glyphicon-plus"></span>
                            <span>Add New Request</span>
                        </a>
                    </div>
                    <br/>
                    <?php if(count($list) > 0){?>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" style="white-space: nowrap; font-size: 12px">
                            <thead>
                                <tr style ="text-align: center">
                                    <td><b>Contract #</b></td>
                                    <td><b>Contract Name</b></td>
                                    <td><b>Contact Person</b></td>
                                    <td><b>Contact #</b></td>
                                    <td><b>Date Booked</b></td>
                                    <td><b>BOS Type</b></td>
                                    <td><b>Order Type</b></td>
                                    <td><b>Shared Order</b></td>
                                    <td><b></b></td>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($list as $list_item): ?>
                                <tr style ="text-align: center">
                                    <td><?php echo $list_item['contract_no']?></td>
                                    <td><?php echo $list_item['contract_name']?></td>
                                    <td><?php echo $list_item['contact_person']?></td>
                                    <td><?php echo $list_item['landline_no']; if(!is_null($list_item['mobile_no']) || !is_null($list_item['landline_no']))echo ' / '; echo $list_item['mobile_no']?></td>
                                    <td><?php echo $list_item['date_booked']?></td>
                                    <td><?php echo $list_item['bos_transactype']?></td>
                                    <td><?php echo $list_item['order_type']?></td>
                                    <td><input type="checkbox" disabled
                                            <?php if(!is_null($list_item['isshared_order'])) echo 'checked = "on"'; ?>></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Action <span class="caret"></span>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-right">
                                                    <li><a href ="<?php echo base_url('gcrequest/edit?id='.$list_item['id'])?>" ><span class="fa fa-pencil fa-fw"></span> Edit</a></li>
                                                    <li><a href ="<?php echo base_url('gcrequest/addrequest?id='.$list_item['id'])?>" ><span class="fa fa-archive fa-fw"></span>  View details</a></li>
                                                    <li><a href ="<?php echo base_url('gcrequest/addrequest?id='.$list_item['id'])?>" ><span class="fa fa-trash fa-fw"></span> Delete</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php } else { ?>
                    <div class="alert alert-warning alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        No Records Found.
                    </div>
                    <?php } ?>
                </div>
                <!-- /.col-lg-12 -->
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>