<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-header">
                    <h2>Contract Entry</h2>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <?php echo form_open(base_url('contract/edit'));?>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Contract #</label>
                    <input type="text" class="form-control" id="contractno" name="contractno" placeholder="Contract #" value="<?php echo set_value('contractno'); ?>">
                    <span class="text-danger"><?php echo form_error('contractno'); ?></span>
                </div>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Contract Name</label>
                    <input type="text" class="form-control" id="contractname" name="contractname" placeholder="Contract Name" value="<?php echo set_value('contractname'); ?>">
                    <span class="text-danger"><?php echo form_error('contractname'); ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <button id="btn_login" name="btn_add" type="submit" class="btn btn-primary" value="add">Add Contract</button>
                </div>
                <?php echo form_close(); ?>
                <div class="clearfix"></div>

                <br /><br />
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>

