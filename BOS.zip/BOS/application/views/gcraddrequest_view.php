<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-header">
                    <h2>Add GC Request</h2>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <?php echo form_open(base_url('gcrequest/addrequest?id='.$_GET['id']));?>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Store Name: </label>
                    <span><?php echo $list[0]['store_code']; ?></span>
                </div>
                <div class="clearfix"></div>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>JPLS Target</label>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>November 15 - December 13 : </label>
                    <span><?php echo $list[0]['jstarget_nov']; ?></span>
                </div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>December 14 - December 31 : </label>
                    <span><?php echo $list[0]['jstarget_dec']; ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>JPLS Target Total : </label>
                    <span><?php echo $list[0]['jstarget_total']; ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Initial GC  Request : </label>
                    <span><?php echo $list[0]['ini_gcrequest']; ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>50s GC</label>
                    <input type="text" class="form-control" id="add50" name="add50" placeholder="50s GC"
                           value="<?php echo set_value('add50'); ?>">
                    <span class="text-danger"><?php echo form_error('add50'); ?></span>
                </div>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Amount</label>
                    <input type="text" readonly = "readonly" class="form-control " id="add50amt" name="add50amt" placeholder="50s GC Amount"
                           value="<?php echo set_value('add50amt'); ?>">
                    <span class="text-danger"><?php echo form_error('add50amt'); ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>100s GC</label>
                    <input type="text" class="form-control" id="add100" name="add100" placeholder="100s GC"
                           value="<?php echo set_value('add100'); ?>">
                    <span class="text-danger"><?php echo form_error('add100'); ?></span>
                </div>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Amount</label>
                    <input type="text" readonly = "readonly" class="form-control" id="add100amt" name="add100amt" placeholder="100s GC Amount"
                           value="<?php echo set_value('add100amt'); ?>">
                    <span class="text-danger"><?php echo form_error('add100amt'); ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Pie Cards</label>
                    <input type="text" class="form-control" id="addPie" name="addPie" placeholder="Pie Cards"
                           value="<?php echo set_value('addPie'); ?>">
                    <span class="text-danger"><?php echo form_error('addPie'); ?></span>
                </div>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Amount</label>
                    <input type="text" readonly = "readonly" class="form-control" id="addPieamt" name="addPieamt" placeholder="Pie Cards Amount"
                           value="<?php echo set_value('addPieamt'); ?>">
                    <span class="text-danger"><?php echo form_error('addPieamt'); ?></span>
                </div>
                <div class="clearfix"></div>
                <br/>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <button id="btn_login" name="btn_addreq" type="submit" class="btn btn-primary" value="addreq">Edit Request</button>
                </div>

                <?php echo form_close(); ?>
                <div class="clearfix"></div>

                <br /><br />
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
    <!--    <script src="--><?php //echo base_url('assets/vendor/jquery/jquery.min.js')?><!--"></script>-->
    <script type="text/javascript">
        $( "#add50, #add100, #addpie" ).keyup(function() {
            $('#'+this.id+'amt').val(($(this).val())*2  );
        });
    </script>


