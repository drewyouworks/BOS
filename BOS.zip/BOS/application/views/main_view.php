<!-- DataTables CSS -->
<link href="<?php echo base_url('assets/vendor/datatables-plugins/dataTables.bootstrap.css') ?>" rel="stylesheet">

<!-- DataTables Responsive CSS -->
<link href="<?php echo base_url('assets/vendor/datatables-responsive/dataTables.responsive.css') ?>" rel="stylesheet">

<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-header">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Dashboard
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTables-example" style="white-space: nowrap; font-size: 12px">
                                <thead>
                                    <tr>
                                        <td><b>Store Code</b></td>
                                        <td><b>Store Name</b></td>
                                        <td><b>RBU</b></td>
                                        <td><b>Contract #</b></td>
                                        <td><b>Date Booked</b></td>
                                        <td><b>Type</b></td>
                                        <td><b>Booking Type</b></td>
                                        <td><b>NKG Transaction</b></td>
                                        <td><b>Previous Customer</b></td>
                                        <td><b>Previous Customer Since</b></td>
                                        <td><b>Customer</b></td>
                                        <td><b>Position</b></td>
                                        <td><b>Landline#</b></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Store Code 1</td>
                                        <td>Store Name 1</td>
                                        <td>RBU 1</td>
                                        <td>Contract # 1</td>
                                        <td>Date Booked 1</td>
                                        <td>Type 1</td>
                                        <td>Booking Type 1</td>
                                        <td>NKG Transaction 1</td>
                                        <td>Previous Customer 1</td>
                                        <td>Previous Customer Since 1</td>
                                        <td>Customer 1</td>
                                        <td>Position 1</td>
                                        <td>Landline# 1</td>
                                    </tr>
                                    <tr>
                                        <td>Store Code 2</td>
                                        <td>Store Name 2</td>
                                        <td>RBU 2</td>
                                        <td>Contract # 2</td>
                                        <td>Date Booked 2</td>
                                        <td>Type 2</td>
                                        <td>Booking Type 2</td>
                                        <td>NKG Transaction 2</td>
                                        <td>Previous Customer 2</td>
                                        <td>Previous Customer Since 2</td>
                                        <td>Customer 2</td>
                                        <td>Position 2</td>
                                        <td>Landline# 2</td>
                                    </tr>
                                    <tr>
                                        <td>Store Code 3</td>
                                        <td>Store Name 3</td>
                                        <td>RBU 3</td>
                                        <td>Contract # 3</td>
                                        <td>Date Booked 3</td>
                                        <td>Type 3</td>
                                        <td>Booking Type 3</td>
                                        <td>NKG Transaction 3</td>
                                        <td>Previous Customer 3</td>
                                        <td>Previous Customer Since 3</td>
                                        <td>Customer 3</td>
                                        <td>Position 3</td>
                                        <td>Landline# 3</td>
                                    </tr>
                                    <tr>
                                        <td>Store Code 4</td>
                                        <td>Store Name 4</td>
                                        <td>RBU 4</td>
                                        <td>Contract # 4</td>
                                        <td>Date Booked 4</td>
                                        <td>Type 4</td>
                                        <td>Booking Type 4</td>
                                        <td>NKG Transaction 4</td>
                                        <td>Previous Customer 4</td>
                                        <td>Previous Customer Since 4</td>
                                        <td>Customer 4</td>
                                        <td>Position 4</td>
                                        <td>Landline# 4</td>
                                    </tr>
                                    <tr>
                                        <td>Store Code 5</td>
                                        <td>Store Name 5</td>
                                        <td>RBU 5</td>
                                        <td>Contract # 5</td>
                                        <td>Date Booked 5</td>
                                        <td>Type 5</td>
                                        <td>Booking Type 5</td>
                                        <td>NKG Transaction 5</td>
                                        <td>Previous Customer 5</td>
                                        <td>Previous Customer Since 5</td>
                                        <td>Customer 5</td>
                                        <td>Position 5</td>
                                        <td>Landline# 5</td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="13">foot</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- DataTables JavaScript -->
<script src="<?php echo base_url('assets/vendor/datatables/js/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/vendor/datatables-plugins/dataTables.bootstrap.min.js') ?>"></script>
<script src="<?php echo base_url('assets/vendor/datatables-responsive/dataTables.responsive.js') ?>"></script>
