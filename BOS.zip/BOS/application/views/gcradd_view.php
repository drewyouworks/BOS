<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-header">
                    <h2>Add GC Request</h2>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <?php echo form_open(base_url('gcrequest/add'));?>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Store Name</label>
                    <input type="text" class="form-control" id="storecode" name="storecode" placeholder="Store Code" value="<?php echo set_value('storecode'); ?>">
                    <span class="text-danger"><?php echo form_error('storecode'); ?></span>
                </div>
                <div class="clearfix"></div><br/>
                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>JPLS Target:</label>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>November 15 - December 13</label>
                    <input type="text" class="form-control" id="jstargetnov" name="jstargetnov" placeholder="November 15 - December 13" value="<?php echo set_value('jstargetnov'); ?>">
                    <span class="text-danger"><?php echo form_error('jstargetnov'); ?></span>
                </div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>December 14 - December 31</label>
                    <input type="text" class="form-control" id="jstargetdec" name="jstargetdec" placeholder="December 14 - December 31" value="<?php echo set_value('jstargetdec'); ?>">
                    <span class="text-danger"><?php echo form_error('jstargetdec'); ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>JPLS Target Total</label>
                    <input type="text" readonly="readonly" class="form-control" id="jstargettotal" name="jstargettotal" placeholder="JPLS Target Total" value="<?php echo set_value('jstargettotal'); ?>">
                    <span class="text-danger"><?php echo form_error('jstargettotal'); ?></span>
                </div>
                <div class="clearfix"></div>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <label>Initial GC  Request</label>
                    <input type="text" readonly="readonly" class="form-control" id="ini_gcrequest" name="ini_gcrequest" placeholder="Initial GC  Request" value="<?php echo set_value('ini_gcrequest'); ?>">
                    <span class="text-danger"><?php echo form_error('ini_gcrequest'); ?></span>
                </div>
                <div class="clearfix"></div>
                <br/>

                <div class="form-group col-xs-10 col-sm-4 col-md-4 col-lg-4">
                    <button id="btn_login" name="btn_add" type="submit" class="btn btn-primary" value="add">Add Request</button>
                </div>

                <?php echo form_close(); ?>
                <div class="clearfix"></div>

                <br /><br />
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
    <script type="text/javascript">
        $( "#jstargetnov, #jstargetdec" ).keyup(function() {
            $('#jstargettotal').val(parseFloat($('#jstargetdec').val())+parseFloat($('#jstargetnov').val()));
            $('#ini_gcrequest').val(parseFloat($('#jstargetdec').val())+parseFloat($('#jstargetnov').val()));
        });
    </script>



