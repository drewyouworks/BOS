<?php
    class Main extends CI_Controller {
        public function index(){
            //$this->load->model('flight_model');

            //$data['query'] = $this->flight_model->flightlist();

            $this->load->view('/templates/loadscript');
            $this->load->view('/templates/header-nav');
            $this->load->view('main_view');
            $this->load->view('/templates/footer');
        }

    }