<?php
    class Contract extends CI_Controller {

        public function __construct()
        {
            parent::__construct();
            $this->load->library('session');
            $this->load->library('form_validation');
            $this->load->helper('form','url','html');
            $this->load->database();
            $this->load->model('contract_model');
        }

        public function index()
        {

            $data['list'] = $this->contract_model->showList();

            $this->load->view('/templates/loadscript',$data);
            $this->load->view('/templates/header-nav',$data);
            $this->load->view('contractlist_view',$data);
            $this->load->view('/templates/footer');
        }

        public function add()
        {
            //get the posted values
            $contractno = $this->input->post("contractno");
            $contractname = $this->input->post("contractname");
            $contactperson= $this->input->post('contactperson');
            $address = $this->input->post('address');
            $landline = $this->input->post('landline');
            $mobile = $this->input->post('mobile');
            $prevcust = $this->input->post('prevcust');
            $custsince = strtotime($this->input->post('custsince'));
            $datebooked = strtotime($this->input->post('datebooked'));
            $bostransac = $this->input->post('bostransac');
            $ordertype = $this->input->post('ordertype');
            $shared = $this->input->post('shared');
            $mother = $this->input->post('mother');
            $custprofile = $this->input->post('custprofile');
            $otherprofile = $this->input->post('otherprofile');
            $this->load->helper('string');
            $sys_refno = random_string('alnum',10);
            //set validations
            $this->form_validation->set_rules("contractno", "Contract #", "trim|required");
            $this->form_validation->set_rules("contractname", "Contract Name", "trim|required");
            $this->form_validation->set_rules("contactperson", "Contact Person", "trim|required");
            $this->form_validation->set_rules("address", "Address", "trim|required");
            $this->form_validation->set_rules("landline", "Landline #", "trim|required");
            $this->form_validation->set_rules("mobile", "Mobile #", "trim|required");
            $this->form_validation->set_rules("custprofile", "Customer Profile", "trim|required");
            if(!is_null($prevcust)) $this->form_validation->set_rules("custsince", "Customer Since", "trim|required");
            $this->form_validation->set_rules("datebooked", "Date Booked", "trim|required");
            $this->form_validation->set_rules("bostransac", "Kind of BOS Transaction", "trim|required");
            $this->form_validation->set_rules("ordertype", "Type of Order", "trim|required");
            if($custprofile == 'Others') $this->form_validation->set_rules("otherprofile", "Customer Profile", "trim|required");

            if ($this->form_validation->run() == FALSE)
            {
                //validation fails
                $this->load->view('/templates/loadscript');
                $this->load->view('/templates/header-nav');
                $this->load->view('contractadd_view');
                $this->load->view('/templates/footer');
            }
            else
            {
                //validation succeeds
                if ($this->input->post('btn_add') == "add")
                {
                    while($this->contract_model->checkRefno($sys_refno)){
                        $sys_refno = random_string('alnum',20);
                    }

                    $toBeInserted = array(
                        'contract_no' => $contractno,
                        'contract_name' => $contractname,
                        'contact_person' => $contactperson,
                        'address' => $address,
                        'landline_no' => $landline,
                        'mobile_no' => $mobile,
                        'isprevious_cust' => $prevcust,
                        'customer_since' => date('Y-m-d',$custsince),
                        'date_booked' => date('Y-m-d',$datebooked),
                        'bos_transactype' => $bostransac,
                        'order_type' => $ordertype,
                        'isshared_order' => $shared,
                        'ismother' => $mother,
                        'cust_profile' => $custprofile,
                        'cust_specify' => $otherprofile,
                        'sys_refno' => $sys_refno
                    );

                    $this->contract_model->insertToDB($toBeInserted);
                    redirect(base_url('contract?action=addsuccess'));
                }
                else
                {
                    redirect(base_url('contract/add'));
                }
            }
        }

        public function edit(){
            if(isset($_GET['id'])){
                //get the posted values
                $contractno = $this->input->post("contractno");
                $contractname = $this->input->post("contractname");
                $contactperson= $this->input->post('contactperson');
                $address = $this->input->post('address');
                $landline = $this->input->post('landline');
                $mobile = $this->input->post('mobile');
                $prevcust = $this->input->post('prevcust');
                $custsince = strtotime($this->input->post('custsince'));
                $datebooked = strtotime($this->input->post('datebooked'));
                $bostransac = $this->input->post('bostransac');
                $ordertype = $this->input->post('ordertype');
                $shared = $this->input->post('shared');
                $mother = $this->input->post('mother');
                $custprofile = $this->input->post('custprofile');
                $otherprofile = $this->input->post('otherprofile');
                $this->load->helper('string');
                $sys_refno = random_string('alnum',10);
                //set validations
                $this->form_validation->set_rules("contractno", "Contract #", "trim|required");
                $this->form_validation->set_rules("contractname", "Contract Name", "trim|required");
                $this->form_validation->set_rules("contactperson", "Contact Person", "trim|required");
                $this->form_validation->set_rules("address", "Address", "trim|required");
                $this->form_validation->set_rules("landline", "Landline #", "trim|required");
                $this->form_validation->set_rules("mobile", "Mobile #", "trim|required");
                $this->form_validation->set_rules("custprofile", "Customer Profile", "trim|required");
                if(!is_null($prevcust)) $this->form_validation->set_rules("custsince", "Customer Since", "trim|required");
                $this->form_validation->set_rules("datebooked", "Date Booked", "trim|required");
                $this->form_validation->set_rules("bostransac", "Kind of BOS Transaction", "trim|required");
                $this->form_validation->set_rules("ordertype", "Type of Order", "trim|required");
                if($custprofile == 'Others') $this->form_validation->set_rules("otherprofile", "Customer Profile", "trim|required");

                if ($this->form_validation->run() == FALSE)
                {
                    //validation fails
                    $this->load->view('/templates/loadscript');
                    $this->load->view('/templates/header-nav');
                    //$this->load->view('contractadd_view');
                    $this->load->view('/templates/footer');
                }
                else
                {
                    //validation succeeds
                    if ($this->input->post('btn_edit') == "edit")
                    {
                        while($this->contract_model->checkRefno($sys_refno)){
                            $sys_refno = random_string('alnum',20);
                        }

                        $toBeInserted = array(
                            'contract_no' => $contractno,
                            'contract_name' => $contractname,
                            'contact_person' => $contactperson,
                            'address' => $address,
                            'landline_no' => $landline,
                            'mobile_no' => $mobile,
                            'isprevious_cust' => $prevcust,
                            'customer_since' => date('Y-m-d',$custsince),
                            'date_booked' => date('Y-m-d',$datebooked),
                            'bos_transactype' => $bostransac,
                            'order_type' => $ordertype,
                            'isshared_order' => $shared,
                            'ismother' => $mother,
                            'cust_profile' => $custprofile,
                            'cust_specify' => $otherprofile,
                            'sys_refno' => $sys_refno
                        );

                        redirect(base_url('contract?action=editsuccess'));
                    }
                    else
                    {
                        redirect(base_url('contract/add'));
                    }
                }
            }
        }


    }