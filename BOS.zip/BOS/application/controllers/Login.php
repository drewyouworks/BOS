<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->library('form_validation');
        $this->load->helper('form','url','html');
        $this->load->database();
        //load the login model
        $this->load->model('login_model');
    }

    public function index()
    {
        //get the posted values
        $username = $this->input->post("txt_username");
        $password = $this->input->post("txt_password");

        //set validations
        $this->form_validation->set_rules("txt_username", "Username", "trim|required");
        $this->form_validation->set_rules("txt_password", "Password", "trim|required");

        if ($this->form_validation->run() == FALSE)
        {
            //validation fails
            $this->load->view('login_view');
        }
        else
        {
            //validation succeeds
            if ($this->input->post('btn_login') == "login")
            {
                //check if username and password is correct
                $usr_result = $this->login_model->get_user($username, $password);
                if ($usr_result > 0) //active user record is present
                {
                    //set the session variables
                    $sessiondata = array(
                        'username' => $username,
                        'loginuser' => TRUE
                    );
                    $this->session->set_userdata($sessiondata);
                    redirect(base_url().'main');
                }
                else
                {
                    $this->session->set_flashdata('msg', '<p class="text-danger">Invalid username and password!</p>');
                    redirect(base_url('login'));
                }
            }
            else
            {
                redirect(base_url('login'));
            }
        }
    }
}