<?php
    class Gcrequest extends CI_Controller
    {
        public function __construct()
        {
            parent::__construct();
            $this->load->library('session');
            $this->load->library('form_validation');
            $this->load->helper('form','url','html');
            $this->load->database();
            $this->load->model('gcrequest_model');
        }

        public function index()
        {
            $data['list'] = $this->gcrequest_model->showList();
            $this->load->view('/templates/loadscript',$data);
            $this->load->view('/templates/header-nav',$data);
            $this->load->view('gcrlist_view',$data);
            $this->load->view('/templates/footer');
        }

        public function add()
        {

            //get the posted values
            $storecode = $this->input->post("storecode");
            $jstargetnov = $this->input->post("jstargetnov");
            $jstargetdec = $this->input->post("jstargetdec");
            $jstargettotal = $this->input->post("jstargettotal");
            $ini_gcrequest = $this->input->post("ini_gcrequest");
            $this->load->helper('string');
            $sys_refno = random_string('alnum',10);

            //set validations
            $this->form_validation->set_rules("storecode", "Store Code", "trim|required");
            $this->form_validation->set_rules("jstargetnov", "Nov 15 - Dec 13", "trim|required|numeric|greater_than[0]");
            $this->form_validation->set_rules("jstargetdec", "Dec 13 - Nov 31", "trim|required|numeric|greater_than[0]");


            if ($this->form_validation->run() == FALSE)
            {
                //validation fails
                $this->load->view('/templates/loadscript');
                $this->load->view('/templates/header-nav');
                $this->load->view('gcradd_view');
                $this->load->view('/templates/footer');
            }
            else
            {
                //validation succeeds
                if ($this->input->post('btn_add') == "add")
                {
                    while($this->gcrequest_model->checkRefno($sys_refno)){
                        $sys_refno = random_string('alnum',20);
                    }

                    $toBeInserted = array(
                        'store_code' => $storecode,
                        'jstarget_nov' => $jstargetnov,
                        'jstarget_dec' => $jstargetdec,
                        'jstarget_total' => $jstargettotal,
                        'ini_gcrequest' => $ini_gcrequest,
                        'sys_refno' => $sys_refno
                    );

                    $this->gcrequest_model->insertToDB($toBeInserted);
                    redirect(base_url('gcrequest'));
                }
                else
                {
                    redirect(base_url('gcrequest/add'));
                }
            }
        }

        public function edit(){
            if(isset($_GET['id'])){
                $storecode = $this->input->post("storecode");
                $jstargetnov = $this->input->post("jstargetnov");
                $jstargetdec = $this->input->post("jstargetdec");
                $jstargettotal = $this->input->post("jstargettotal");
                $ini_gcrequest = $this->input->post("ini_gcrequest");

                $this->form_validation->set_rules("storecode", "Store Code", "trim|required");
                $this->form_validation->set_rules("jstargetnov", "Nov 15 - Dec 13", "trim|required|numeric|greater_than[0]");
                $this->form_validation->set_rules("jstargetdec", "Dec 13 - Nov 31", "trim|required|numeric|greater_than[0]");
                $this->form_validation->set_rules("jstargettotal", "JPLS Target", "trim|required|numeric|greater_than[0]");
                $this->form_validation->set_rules("ini_gcrequest", "Initial GC Request", "trim|required|numeric|greater_than[0]");

                if ($this->form_validation->run() == FALSE) {
                    //validation fails
                    $data['list'] = $this->gcrequest_model->singleSelect($_GET['id']);

                    $this->load->view('/templates/loadscript',$data);
                    $this->load->view('/templates/header-nav',$data);
                    $this->load->view('gcredit_view',$data);
                    $this->load->view('/templates/footer');
                } else {
                    //validation succeeds
                    if ($this->input->post('btn_edit') == "edit") {
                        $toBeUpdated = array(
                            'store_code' => $storecode,
                            'jstarget_nov' => $jstargetnov,
                            'jstarget_dec' => $jstargetdec,
                            'jstarget_total' => $jstargettotal,
                            'ini_gcrequest' => $ini_gcrequest
                        );
                        $this->gcrequest_model->updateRow($toBeUpdated, $_GET['id']);
                        redirect(base_url('gcrequest'));
                    } else {
                        redirect(base_url('gcrequest/edit?id='.$_GET['id']));
                    }
                }
            }
        }

        public function addrequest(){
            if(isset($_GET['id'])){
                $add50 = $this->input->post("add50");
                $add50amt = $this->input->post("add50amt");
                $add100 = $this->input->post("add100");
                $add100amt = $this->input->post("add100amt");
                $addpie = $this->input->post("addPie");
                $addpieamt = $this->input->post("addPieamt");

                $this->form_validation->set_rules("add50", "50s GC", "trim|required|numeric|greater_than[0]");
                $this->form_validation->set_rules("add50amt", "Amount", "trim|required|numeric|greater_than[0]");
                $this->form_validation->set_rules("add100", "100s GC", "trim|required|numeric|greater_than[0]");
                $this->form_validation->set_rules("add100amt", "Amount", "trim|required|numeric|greater_than[0]");
                $this->form_validation->set_rules("addPie", "Pie Cards", "trim|required|numeric|greater_than[0]");
                $this->form_validation->set_rules("addPieamt", "Amount", "trim|required|numeric|greater_than[0]");

                if ($this->form_validation->run() == FALSE) {
                    //validation fails
                    $data['list'] = $this->gcrequest_model->singleSelect($_GET['id']);

                    $this->load->view('/templates/loadscript',$data);
                    $this->load->view('/templates/header-nav',$data);
                    $this->load->view('gcraddrequest_view',$data);
                    $this->load->view('/templates/footer');
                } else {
                    //validation succeeds
                    if ($this->input->post('btn_addreq') == "addreq") {
                        $toBeUpdated = array(
                            'add_50gc'  => $add50,
                            'gc50_amt'  => $add50amt,
                            'add_100gc' => $add100,
                            'gc100_amt' => $add100amt,
                            'add_piegc' => $addpie,
                            'gcpie_amt' => $addpieamt
                        );
                        $this->gcrequest_model->updateRow($toBeUpdated, $_GET['id']);
                        redirect(base_url('gcrequest'));
                    } else {
                        redirect(base_url('gcrequest/addrequest?id='.$_GET['id']));
                    }
                }
            }
        }

    }