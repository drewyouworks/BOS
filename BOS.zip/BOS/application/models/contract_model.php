<?php
     class Contract_model extends CI_Model {

         public function __construct()
         {
             $this->load->database();
         }
         public function showList() {
             $query = $this->db->get('contracts');
             return $query->result_array();
         }

         public function singleSelect($row){
             $this->db->where('id', $row);
             $query = $this->db->get('contracts');
             return $query->result_array();
         }

         public function insertToDB($data)
         {
             $this->db->insert('contracts',$data);
         }

         public function updateRow($data, $row){
             $this->db->where('id', $row);
             $this->db->update('contracts', $data);
         }

         public function checkRefno($str){
             $this->db->select('id');
             $this->db->where('sys_refno', $str);
             $query = $this->db->get('contracts');

             if ($query->num_rows() > 0) {
                 return true;
             } else {
                 return false;
             }
         }
     }