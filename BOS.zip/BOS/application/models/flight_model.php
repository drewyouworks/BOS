<?php
 class Flight_model extends CI_Model{

//     public function __construct()
//     {
//         $this->load->database();
//     }
//
//
//     public function flightlist(){
//        $query = $this->db->get('input_flightsched');
//        return $query->result_array();
//    }
 }